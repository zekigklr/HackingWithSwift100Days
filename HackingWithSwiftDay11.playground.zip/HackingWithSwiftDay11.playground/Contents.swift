import UIKit

//Hacking With Swift Day 11
//Day 11 – protocols, extensions, and protocol extensions

// protokoller
/**


 Protokoller, bir şeyin hangi özelliklere ve yöntemlere sahip olması gerektiğini tanımlamanın bir yoludur. Daha sonra Swift'e hangi türlerin bu protokolü kullandığını söylersiniz - bir protokolü benimsemek veya buna uymak olarak bilinen bir süreç.

 Örneğin, bir idözelliği olan bir şeyi kabul eden bir fonksiyon yazabiliriz, ancak tam olarak ne tür verilerin kullanıldığı umursamıyoruz. IdentifiableTüm uyumlu türlerin idokunabilen ("al") veya yazılabilen ("set") bir dizeye sahip olmasını gerektiren bir protokol oluşturarak başlayacağız :

 protocol Identifiable {
     var id: String { get set }
 }
 Bu protokolün örneklerini oluşturamayız - bu, doğrudan oluşturup kullanabileceğimiz bir şey değil, istediğimiz şeyin bir açıklamasıdır. Ancak buna uygun bir yapı oluşturabiliriz:

 struct User: Identifiable {
     var id: String
 }
 Son olarak, herhangi bir nesneyi displayID()kabul eden bir fonksiyon yazacağız :Identifiable

 func displayID(thing: Identifiable) {
     print("My ID is \(thing.id)")
 }
 */

// Protokol devralma
/**

 Bir protokol, protokol mirası olarak bilinen bir süreçte diğerinden miras alabilir . Sınıflardan farklı olarak, üstüne kendi özelleştirmelerinizi eklemeden önce aynı anda birden çok protokolden miras alabilirsiniz.

 Üç protokol tanımlayacağız: Payablebir calculateWages()yöntemi uygulamak NeedsTrainingiçin uyumlu türler gerektirir, bir yöntemi uygulamak için uyumlu türler gerektirir study()ve bir yöntemi uygulamak HasVacationiçin uyumlu türler gerektirir takeVacation():

 protocol Payable {
     func calculateWages() -> Int
 }

 protocol NeedsTraining {
     func study()
 }

 protocol HasVacation {
     func takeVacation(days: Int)
 }
 Artık Employeeonları tek bir protokolde bir araya getiren tek bir protokol oluşturabiliriz. Üstüne herhangi bir şey eklememize gerek yok, bu yüzden sadece açık ve kapalı parantezler yazacağız:

 protocol Employee: Payable, NeedsTraining, HasVacation { }
 Artık yeni türleri, üç ayrı protokolün her biri yerine bu tek protokole uygun hale getirebiliriz.
 */

// Uzantılar
/**


 Uzantılar, var olan türlere yöntemler eklemenize, orijinal olarak tasarlanmadıkları şeyleri yapmalarını sağlamanıza olanak tanır.

 Örneğin, Inttüre bir uzantı ekleyebiliriz, böylece squared()geçerli sayının kendisiyle çarpımını döndüren bir yönteme sahip olur:

 extension Int {
     func squared() -> Int {
         return self * self
     }
 }
 squared()Bunu denemek için, sadece bir tamsayı oluşturun ve bunun artık bir yöntemi olduğunu göreceksiniz :

 let number = 8
 number.squared()
 Swift, uzantılara depolanmış özellikler eklemenize izin vermez, bu nedenle bunun yerine hesaplanmış özellikleri kullanmanız gerekir. Örneğin, isEventamsayılara, çift sayı içeriyorsa true döndüren yeni bir hesaplanmış özellik ekleyebiliriz:

 extension Int {
     var isEven: Bool {
         return self % 2 == 0
     }
 }
 */

// Protokol uzantıları
/**


 Protokoller, bir şeyin hangi yöntemlere sahip olması gerektiğini tanımlamanıza izin verir, ancak içindeki kodu sağlamaz. Uzantılar, yöntemlerinizin içindeki kodu sağlamanıza izin verir, ancak yalnızca bir veri türünü etkiler; yöntemi aynı anda çok sayıda türe ekleyemezsiniz.

 IntProtokol uzantıları bu iki sorunu da çözer: Sizin gibi belirli bir türü genişletmek yerine, tüm uyumlu türlerin değişikliklerinizi alması için tüm protokolü genişletmek dışında normal uzantılar gibidirler .

 Örneğin, bazı adları içeren bir dizi ve küme:

 let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]
 let beatles = Set(["John", "Paul", "George", "Ringo"])
 Swift'in dizileri ve kümeleri, adlı bir protokole uygundur , bu nedenle koleksiyonu düzgün bir şekilde yazdırmak için Collectionbir yöntem eklemek için bu protokole bir uzantı yazabiliriz.summarize()

 extension Collection {
     func summarize() {
         print("There are \(count) of us:")

         for name in self {
             print(name)
         }
     }
 }
 Her ikisi de Arrayve Setşimdi bu yönteme sahip olacak, böylece deneyebiliriz:

 pythons.summarize()
 beatles.summarize()
 */

// Protokol odaklı programlama
/**

 Protokol uzantıları, kendi protokol yöntemlerimiz için varsayılan uygulamalar sağlayabilir. Bu, türlerin bir protokole uymasını kolaylaştırır ve "protokol odaklı programlama" adı verilen bir tekniğe izin verir - kodunuzu protokoller ve protokol uzantıları etrafında oluşturur.

 Identifiableİlk olarak, herhangi bir uygun türün bir idözelliğe ve bir identify()yönteme sahip olmasını gerektiren bir protokol adı verilir :

 protocol Identifiable {
     var id: String { get set }
     func identify()
 }
 Her uygun türün kendi yöntemini yazmasını sağlayabiliriz ,identify() ancak protokol uzantıları bir varsayılan sağlamamıza izin verir:

 extension Identifiable {
     func identify() {
         print("My ID is \(id).")
     }
 }
 IdentifiableŞimdi buna uyan bir tür oluşturduğumuzda identify()otomatik olarak:

 struct User: Identifiable {
     var id: String
 }

 let twostraws = User(id: "twostraws")
 twostraws.identify()
 */

//Protokoller ve uzantılar özeti
/**
 

 Bu serinin dokuzuncu bölümünün sonuna geldiniz, o halde özetleyelim:

 Protokoller, uygun bir türün hangi yöntemlere ve özelliklere sahip olması gerektiğini açıklar, ancak bu yöntemlerin uygulamalarını sağlamaz.
 Sınıflara benzer şekilde diğer protokollerin üzerine protokoller oluşturabilirsiniz.
 Uzantılar, gibi belirli türlere yöntemler ve hesaplanmış özellikler eklemenize olanak tanır Int.
 Protokol uzantıları, protokollere yöntemler ve hesaplanmış özellikler eklemenize olanak tanır.
 Protokol odaklı programlama, uygulama mimarinizi bir dizi protokol olarak tasarlama ve ardından varsayılan yöntem uygulamalarını sağlamak için protokol uzantılarını kullanma pratiğidir.

 */

