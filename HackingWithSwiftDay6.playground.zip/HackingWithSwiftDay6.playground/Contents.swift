import UIKit


//Hacking With Swift Day 6
//Day 6 – closures part one

//Temel kapatmalar oluşturma
/**
 

 Swift, dizeler ve tamsayılar gibi diğer türler gibi işlevleri kullanmamıza izin verir. Bu, bir işlev oluşturup onu bir değişkene atayabileceğiniz, bu değişkeni kullanarak bu işlevi çağırabileceğiniz ve hatta bu işlevi diğer işlevlere parametre olarak geçirebileceğiniz anlamına gelir.

 Bu şekilde kullanılan işlevlere kapanışlar denir ve işlevler gibi çalışsalar da biraz farklı yazılırlar.

 Bir mesaj yazdıran basit bir örnekle başlayalım:

 let driving = {
     print("I'm driving in my car")
 }
 Bu, isimsiz bir işlev yaratır ve bu işlevi driving. Artık driving()normal bir işlevmiş gibi arayabilirsiniz, şöyle:

 driving()

 //Bir kapatmada parametreleri kabul etme
 /*
 Kapanışlar oluşturduğunuzda, herhangi bir parametre yazmak için bir adları veya boşlukları yoktur. Bu, parametreleri kabul edemeyecekleri anlamına gelmez , sadece bunu farklı bir şekilde yaparlar: açık parantezler içinde listelenirler.
 Bir kapanışın parametreleri kabul etmesini sağlamak için, bunları açılış parantezinden hemen sonra parantez içinde listeleyin, ardından inSwift'in kapanışın ana gövdesinin başladığını bilmesi için yazın.
 Örneğin, bir yer adı dizesini tek parametresi olarak kabul eden bir kapatma yapabiliriz:
 let driving = { (place: String) in
     print("I'm going to \(place) in my car")
 }
 İşlevler ve kapatmalar arasındaki farklardan biri, kapatmaları çalıştırırken parametre etiketlerini kullanmamanızdır. Yani, driving()şimdi aramak için şunu yazardık:
 driving("London")
 */

 //Bir kapanıştan değerleri döndürme
 /*
 Kapanışlar da değerler döndürebilir ve parametrelere benzer şekilde yazılırlar: bunları, inanahtar kelimeden hemen önce, kapanışınızın içine yazarsınız.
 Bunu göstermek için, kapanışımızı alacağız driving()ve doğrudan yazdırmak yerine değerini döndürmesini sağlayacağız. İşte orijinal:
 let driving = { (place: String) in
     print("I'm going to \(place) in my car")
 }
 İletiyi doğrudan yazdırmak yerine bir dize döndüren bir kapatma istiyoruz, bu nedenle -> Stringönce kullanmamız inve ardından returnnormal bir işlev gibi kullanmamız gerekiyor:
 let drivingWithReturn = { (place: String) -> String in
     return "I'm going to \(place) in my car"
 }
 Artık bu kapanışı çalıştırabilir ve dönüş değerini yazdırabiliriz:
 let message = drivingWithReturn("London")
 print(message)
 */

 //Parametre olarak kapanışlar
 /*
 Kapanışlar tıpkı dizeler ve tamsayılar gibi kullanılabildiğinden, bunları işlevlere geçirebilirsiniz. Bunun sözdizimi ilk başta beyninize zarar verebilir, bu yüzden yavaştan alacağız.
 İlk olarak, işte driving()yine temel kapanışımız
 let driving = {
     print("I'm driving in my car")
 }
 Eğer o fonksiyonun içinde çalıştırılabilmesi için bu kapanışı bir fonksiyona geçirmek isteseydik, parametre tipini olarak belirtirdik () -> Void. Bu, “hiçbir parametreyi kabul etmez ve geri döner Void” anlamına gelir – Swift'in “hiçbir şey” deme şekli.
 travel()Böylece, farklı türde seyahat eylemlerini kabul eden ve öncesinde ve sonrasında bir mesaj yazdıran bir fonksiyon yazabiliriz :
 func travel(action: () -> Void) {
     print("I'm getting ready to go.")
     action()
     print("I arrived!")
 }
 Artık buna drivingkapanışımızı kullanarak şöyle diyebiliriz:
 travel(action: driving)
 */

 //Sondaki kapatma sözdizimi
 /*
 Bir işlevin son parametresi bir kapatma ise, Swift, sondaki kapatma sözdizimi adı verilen özel sözdizimini kullanmanıza izin verir . Kapanışınızı bir parametre olarak iletmek yerine, onu parantez içindeki fonksiyondan hemen sonra iletirsiniz.
 Bunu göstermek için, işte travel()yine fonksiyonumuz. İki çağrı actionarasında çalıştırılabilmesi için bir kapatmayı kabul eder :print()
 func travel(action: () -> Void) {
     print("I'm getting ready to go.")
     action()
     print("I arrived!")
 }
 travel()Son parametresi bir kapatma olduğundan, aşağıdaki gibi sondaki kapatma sözdizimini kullanarak çağırabiliriz :
 travel() {
     print("I'm driving in my car")
 }
 Aslında başka parametre olmadığı için parantezleri tamamen kaldırabiliriz:
 travel {
     print("I'm driving in my car")
 }
 Sondaki kapatma sözdizimi Swift'de oldukça yaygındır, bu yüzden alışmaya değer.
 */
