import UIKit

//Hacking With Swift Day 7
//Day 7 – closures part two

//Parametreleri kabul ettiklerinde kapakları parametre olarak kullanma
/**
 

 Bu, kapanışların biraz hat gürültüsü gibi okunmaya başlayabileceği yerdir: bir işleve ilettiğiniz bir kapatma, kendi parametrelerini de kabul edebilir.

 " Hiçbir () -> Voidparametre kabul etmiyor ve hiçbir şey döndürmüyor" anlamına geliyorduk, ancak devam edip (), kapatmanızın kabul etmesi gereken herhangi bir parametre türüyle doldurabilirsiniz.

 Bunu göstermek için, tek parametresi olarak bir kapatmayı kabul eden bir fonksiyon yazabiliriz travel()ve bu kapatma da bir dizgeyi kabul eder:

 func travel(action: (String) -> Void) {
     print("I'm getting ready to go.")
     action("London")
     print("I arrived!")
 }
 Şimdi, sondaki kapatma sözdizimini kullanarak çağırdığımızda travel(), bir dizeyi kabul etmek için kapatma kodumuz gerekiyor:

 travel { (place: String) in
     print("I'm going to \(place) in my car")
 }
 */

// Değer döndürdüklerinde kapanışları parametre olarak kullanma
/**

 () -> Void"Parametre kabul etmez ve hiçbir şey döndürmez" anlamında kullandık , ancak bunu Voidherhangi bir veri türüyle değiştirerek kapatmayı bir değer döndürmeye zorlayabilirsiniz.

 Bunu göstermek için travel(), tek parametresi olarak bir kapatmayı kabul eden bir fonksiyon yazabiliriz ve bu kapatma da bir dizgeyi kabul eder ve bir dizge döndürür:

 func travel(action: (String) -> String) {
     print("I'm getting ready to go.")
     let description = action("London")
     print(description)
     print("I arrived!")
 }
 Şimdi, sondaki kapatma sözdizimini kullanarak çağırdığımızda travel(), bir dizeyi kabul etmek ve bir dize döndürmek için kapatma kodumuz gerekir:

 travel { (place: String) -> String in
     return "I'm going to \(place) in my car"
 }
 */

// Kısa yol parametre adları

/**

 Sadece bir travel()fonksiyon yaptık. Kendisi bir parametreyi kabul eden ve bir dize döndüren bir kapatma olan bir parametreyi kabul eder. Bu kapatma daha sonra iki çağrı arasında çalıştırılır print().

 İşte kodda:

 func travel(action: (String) -> String) {
     print("I'm getting ready to go.")
     let description = action("London")
     print(description)
     print("I arrived!")
 }
 travel()Bunun gibi bir şey kullanarak arayabiliriz :

 travel { (place: String) -> String in
     return "I'm going to \(place) in my car"
 }
 Ancak Swift , bu kapatmanın parametresinin bir dizge olması gerektiğini biliyor , bu yüzden onu kaldırabiliriz:

 travel { place -> String in
     return "I'm going to \(place) in my car"
 }
 Ayrıca kapatmanın bir dize döndürmesi gerektiğini de biliyor, böylece bunu kaldırabiliriz:

 travel { place in
     return "I'm going to \(place) in my car"
 }
 Kapatma, değeri döndüren kod olması gereken yalnızca bir kod satırına sahip olduğundan, Swift returnanahtar kelimeyi de kaldırmamıza izin verir:

 travel { place in
     "I'm going to \(place) in my car"
 }
 Swift, daha da kısa gitmenizi sağlayan bir steno sözdizimine sahiptir. Yazmak yerine place inSwift'in kapatma parametreleri için otomatik adlar sağlamasına izin verebiliriz. Bunlar bir dolar işaretiyle, ardından 0'dan itibaren sayılan bir sayıyla adlandırılır.

 travel {
     "I'm going to \($0) in my car"}
 */

// Çoklu parametreli kapanışlar
/**


 Her şeyin açık olduğundan emin olmak için iki parametre kullanarak başka bir kapatma örneği yazacağız.

 Bu sefer travel()fonksiyonumuz, birinin nereye seyahat ettiğini ve gideceği hızı belirten bir kapatma gerektirecektir. (String, Int) -> StringBu , parametrenin türü için kullanmamız gerektiği anlamına gelir :

 func travel(action: (String, Int) -> String) {
     print("I'm getting ready to go.")
     let description = action("London", 60)
     print(description)
     print("I arrived!")
 }
 Bunu takip eden bir kapatma ve steno kapatma parametre adları kullanarak arayacağız. Bu iki parametreyi kabul ettiğinden, ikisini de alacağız $0ve $1:

 travel {
     "I'm going to \($0) at \($1) miles per hour."
 }
 Bazı insanlar kafa karıştırıcı olabileceği için kestirme parametre adları kullanmamayı tercih eder $0ve sorun değil – sizin için en iyi olanı yapın.


 */

// Fonksiyonlardan kapanışları döndürme
/**


 Bir fonksiyona bir kapanış iletebildiğiniz gibi , bir fonksiyondan da kapanışlar alabilirsiniz .

 Bunun sözdizimi biraz kafa karıştırıcıdır, çünkü ilki iki kez kullanır ->: bir kez işlevinizin dönüş değerini belirtmek için ve ikinci kez de kapanışınızın dönüş değerini belirtmek için.

 Bunu denemek için, travel()parametre kabul etmeyen ancak bir kapatma döndüren bir fonksiyon yazacağız. Döndürülen kapatma bir dize ile çağrılmalıdır ve hiçbir şey döndürmez.

 İşte Swift'de nasıl göründüğü:

 func travel() -> (String) -> Void {
     return {
         print("I'm going to \($0)")
     }
 }
 Şimdi travel()bu kapanışı geri almak için arayabiliriz, sonra onu bir fonksiyon olarak çağırabiliriz:

 let result = travel()
 result("London")
 Teknik olarak izin verilir - gerçekten tavsiye edilmemesine rağmen! – dönüş değerini travel()doğrudan şuradan çağırmak için:

 let result2 = travel()("London")
 */

// Değerleri yakalamak
/**


 Kapağınızın içinde herhangi bir harici değer kullanırsanız, Swift bunları yakalar – kapağın yanında saklar, böylece artık mevcut olmasalar bile değiştirilebilirler.

 Şu anda, travel()bir kapatma döndüren bir işlevimiz var ve döndürülen kapatma, bir dizeyi tek parametresi olarak kabul eder ve hiçbir şey döndürmez:

 func travel() -> (String) -> Void {
     return {
         print("I'm going to \($0)")
     }
 }
 Kapatmayı geri almak için arayabilir travel(), ardından bu kapanışı özgürce söyleyebiliriz:

 let result = travel()
 result("London")
 Kapanış yakalama travel(), kapağın içinde kullanılan değerler yaratırsak gerçekleşir. Örneğin, döndürülen kapatmanın ne sıklıkla çağrıldığını izlemek isteyebiliriz:

 func travel() -> (String) -> Void {
     var counter = 1

     return {
         print("\(counter). I'm going to \($0)")
         counter += 1
     }
 }
 counterBu değişken içeride yaratılmış olsa bile travel(), kapatma tarafından yakalanır, bu nedenle bu kapatma için hala hayatta kalacaktır.

 Yani, result("London")birden çok kez ararsak, sayaç yukarı ve yukarı gidecektir:

 result("London")
 result("London")
 result("London")
 */

// Kapanış özeti
/**


 Bu serinin altıncı bölümünün sonuna geldiniz, özetleyelim:

 Değişkenlere kapanışlar atayabilir, daha sonra onları arayabilirsiniz.
 Kapanışlar, normal işlevler gibi parametreleri kabul edebilir ve değerleri döndürebilir.
 Kapanışları parametreler olarak işlevlere geçirebilirsiniz ve bu kapanışların kendi parametreleri ve bir dönüş değeri olabilir.
 İşlevinizin son parametresi bir kapatma ise, sondaki kapatma sözdizimini kullanabilirsiniz.
 Swift otomatik olarak $0ve gibi stenografi parametre adları sağlar $1, ancak herkes bunları kullanmaz.
 Kapaklarınızın içinde harici değerler kullanırsanız, bunlar yakalanır, böylece kapak daha sonra bunlara başvurabilir.

 */

