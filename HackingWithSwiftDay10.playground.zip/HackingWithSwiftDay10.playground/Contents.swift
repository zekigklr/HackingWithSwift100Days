import UIKit

class Dog {
    var name: String
    var breed: String
    
    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
}
let poppy = Dog(name: "Poppy" , breed: "Poodle")

--------------------------------------------------------







//Hacking With Swift Day 10
//Day 10 – classes and inheritance


//Kendi sınıflarınızı oluşturma
/**
 

 Sınıflar, özellikler ve yöntemlerle yeni türler oluşturmanıza izin vermeleri bakımından yapılara benzer, ancak beş önemli farklılıkları vardır ve bu farklılıkların her birini birer birer anlatacağım.

 Sınıflar ve yapılar arasındaki ilk fark, sınıfların hiçbir zaman üye bazında başlatıcı ile gelmemesidir. Bu, sınıfınızda özelliklere sahipseniz, her zaman kendi başlatıcınızı oluşturmanız gerektiği anlamına gelir.

 Örneğin:

 class Dog {
     var name: String
     var breed: String

     init(name: String, breed: String) {
         self.name = name
         self.breed = breed
     }
 }
 Bu sınıfın örneklerini oluşturmak, tıpkı bir yapıymış gibi görünür:

 let poppy = Dog(name: "Poppy", breed: "Poodle")
 */
// sınıf mirası
/**


 Sınıflar ve yapılar arasındaki ikinci fark, mevcut bir sınıfa dayalı bir sınıf oluşturabilmenizdir - orijinal sınıfın tüm özelliklerini ve yöntemlerini devralır ve kendi sınıfını en üste ekleyebilir.

 Buna sınıf mirası veya alt sınıf denir, miras aldığınız sınıfa "üst" veya "süper" sınıf denir ve yeni sınıfa "alt" sınıf denir.

 İşte Dogaz önce oluşturduğumuz sınıf:

 class Dog {
     var name: String
     var breed: String

     init(name: String, breed: String) {
         self.name = name
         self.breed = breed
     }
 }
 adından yola çıkarak yeni bir sınıf oluşturabiliriz Poodle. DogVarsayılan olarak aynı özellikleri ve başlatıcıyı devralır :

 class Poodle: Dog {

 }
 PoodleAncak kendi başlatıcısını da verebiliriz . Her zaman "Finiş" türüne sahip olacağını biliyoruz, bu nedenle yalnızca bir nameözelliğe ihtiyaç duyan yeni bir başlatıcı yapabiliriz. Daha da iyisi, aynı kurulumun gerçekleşmesi Poodleiçin başlatıcının doğrudan başlatıcıyı aramasını sağlayabiliriz:Dog

 class Poodle: Dog {
     init(name: String) {
         super.init(name: name, breed: "Poodle")
     }
 }
 Güvenlik nedenleriyle, Swift sizi her zaman super.init()alt sınıflardan çağırır – tam da ana sınıfın oluşturulduğunda bazı önemli işler yapması ihtimaline karşı.
 */
// geçersiz kılma yöntemleri
/**


 Alt sınıflar, üst yöntemleri kendi uygulamalarıyla değiştirebilir - geçersiz kılma olarak bilinen bir süreç . İşte Dogbir yöntemle önemsiz bir sınıf makeNoise():

 class Dog {
     func makeNoise() {
         print("Woof!")
     }
 }
 'dan miras alan yeni bir Poodlesınıf oluşturursak, yöntemi Dogdevralır . makeNoise()Yani, bu "Hav!" yazdıracak:

 class Poodle: Dog {
 }

 let poppy = Poodle()
 poppy.makeNoise()
 Yöntem geçersiz kılma, sınıf makeNoise()için uygulamasını değiştirmemize olanak tanır .Poodle

 override funcSwift, bir yöntemi geçersiz kılmak yerine kullanmamızı gerektirir func- bu, bir yöntemi yanlışlıkla geçersiz kılmanızı engeller ve üst sınıfta var olmayan bir şeyi geçersiz kılmaya çalışırsanız bir hata alırsınız:

 class Poodle: Dog {
     override func makeNoise() {
         print("Yip!")
     }
 }
 Bu değişiklikle, poppy.makeNoise()“Yip!” Yazdırılacaktır. “Hav!” yerine.


 */
// Son sınıflar
/**


 Sınıf kalıtımı çok yararlı olsa da – ve aslında Apple platformlarının büyük bir kısmı bunu kullanmanızı gerektiriyor – bazen diğer geliştiricilerin sizin sınıflarınızı temel alarak kendi sınıflarını oluşturmasına izin vermemek isteyebilirsiniz.

 Swift bize sadece bu amaç için bir anahtar kelime verir final: bir sınıfı nihai olarak ilan ettiğinizde, başka hiçbir sınıf ondan miras alamaz. Bu, davranışınızı değiştirmek için yöntemlerinizi geçersiz kılamayacakları anlamına gelir - sınıfınızı yazıldığı şekilde kullanmaları gerekir.

 Bir sınıfı final yapmak için finalanahtar kelimeyi şu şekilde önüne koymanız yeterlidir:

 final class Dog {
     var name: String
     var breed: String

     init(name: String, breed: String) {
         self.name = name
         self.breed = breed
     }
 }
 */
// Nesneleri kopyalama
/**


 Sınıflar ve yapılar arasındaki üçüncü fark, nasıl kopyalandıklarıdır. Bir yapıyı kopyaladığınızda, hem orijinal hem de kopya farklı şeylerdir - birini değiştirmek diğerini değiştirmez. Bir sınıfı kopyaladığınızda , hem orijinal hem de kopya aynı şeye işaret eder, bu nedenle birini değiştirmek diğerini de değiştirir.

 Örneğin, varsayılan değere Singersahip bir özelliğe sahip basit bir sınıf :name

 class Singer {
     var name = "Taylor Swift"
 }
 Bu sınıfın bir örneğini oluşturur ve adını yazdırırsak “Taylor Swift” elde ederiz:

 var singer = Singer()
 print(singer.name)
 Şimdi ilkinden ikinci bir değişken oluşturalım ve adını değiştirelim:

 var singerCopy = singer
 singerCopy.name = "Justin Bieber"
 Sınıfların çalışma şekli nedeniyle, her ikisi de singerbellekte singerCopyaynı nesneye işaret eder, bu nedenle şarkıcı adını tekrar yazdırdığımızda “Justin Bieber” ifadesini göreceğiz:

 print(singer.name)
 Öte yandan, eğer Singerbir yapı olsaydı, o zaman ikinci kez “Taylor Swift” yazdırırdık:

 struct Singer {
     var name = "Taylor Swift"
 }

 */
// Başlatıcısızlaştırıcılar
/**


 Sınıflar ve yapılar arasındaki dördüncü fark, sınıfların deinitializer'lara sahip olabilmesidir - bir sınıfın bir örneği yok edildiğinde çalıştırılan kod.

 Bunu göstermek için, özelliği Personolan bir sınıf name, basit bir başlatıcı ve printGreeting()bir mesaj yazdıran bir yöntem:

 class Person {
     var name = "John Doe"

     init() {
         print("\(name) is alive!")
     }

     func printGreeting() {
         print("Hello, I'm \(name)")
     }
 }
 Bir döngü içinde sınıfın birkaç örneğini oluşturacağız Person, çünkü döngü her döndüğünde yeni bir kişi yaratılacak ve sonra yok edilecek:

 for _ in 1...3 {
     let person = Person()
     person.printGreeting()
 }
 Ve şimdi deinitializer için. PersonÖrnek yok edildiğinde bu çağrılacak :

 deinit {
     print("\(name) is no more!")
 }
 */
// değişebilirlik
/**


 Sınıflar ve yapılar arasındaki son fark, sabitlerle uğraşma biçimleridir. Değişken özelliğe sahip sabit bir yapınız varsa, yapının kendisi sabit olduğundan bu özellik değiştirilemez.

 Ancak, değişken özellikli sabit bir sınıfınız varsa , bu özellik değiştirilebilir . mutatingBu nedenle, sınıflar, özellikleri değiştiren yöntemlerle anahtar kelimeye ihtiyaç duymazlar ; bu sadece yapılarla gereklidir.

 Bu fark, sınıf sabit olarak oluşturulduğunda bile bir sınıftaki herhangi bir değişken özelliğini değiştirebileceğiniz anlamına gelir - bu tamamen geçerli koddur:

 class Singer {
     var name = "Taylor Swift"
 }

 let taylor = Singer()
 taylor.name = "Ed Sheeran"
 print(taylor.name)
 Bunun olmasını durdurmak istiyorsanız, özelliği sabit hale getirmeniz gerekir:

 class Singer {
     let name = "Taylor Swift"
 }
 */
// sınıf özeti
/**


 Bu serinin sekizinci bölümünün sonuna geldiniz, o halde özetleyelim:

 Sınıflar ve yapılar benzerdir, çünkü ikisi de özellikler ve yöntemlerle kendi türlerinizi oluşturmanıza izin verir.
 Bir sınıf diğerinden miras alabilir ve ana sınıfın tüm özelliklerini ve yöntemlerini kazanır. Sınıf hiyerarşileri hakkında konuşmak yaygındır - bir sınıf diğerine dayalıdır, kendisi de bir başkasını temel alır.
 Bir sınıfı finalanahtar kelimeyle işaretleyerek diğer sınıfların ondan miras almasını engelleyebilirsiniz.
 Yöntem geçersiz kılma, bir alt sınıfın üst sınıfındaki bir yöntemi yeni bir uygulamayla değiştirmesine olanak tanır.
 İki değişken aynı sınıf örneğini gösterdiğinde, ikisi de aynı bellek parçasını işaret eder - birini değiştirmek diğerini değiştirir.
 Sınıflar, sınıfın bir örneği yok edildiğinde çalıştırılan kod olan bir deinitializer'a sahip olabilir.
 Sınıflar, sabitleri yapılar kadar güçlü bir şekilde zorlamaz - bir özellik değişken olarak bildirilirse, sınıf örneğinin nasıl oluşturulduğuna bakılmaksızın değiştirilebilir.

 */
