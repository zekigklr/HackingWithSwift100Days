import UIKit


//Hacking With Swift Day 13
//I repeat the
/*
Variables and constants,
Types of Data,
Operators,
String interpolation,
Arrays,,
Dictionaries,,
Conditional statements,
Loops,
Switch case,
 */
//Bugün doc formatında wordde yaptım not işlemini buradan ise tekrar ve denemeler yaptım.
/**
 Değişkenler ve sabitler

 Her kullanışlı programın bir noktada veri depolaması gerekir ve Swift'de bunu yapmanın iki yolu vardır: değişkenler ve sabitler. Değişken, değeri istediğiniz zaman değiştirilebilen bir veri deposudur ve sabit, bir kez ayarladığınız ve asla değiştiremeyeceğiniz bir veri deposudur. Yani değişkenlerin değişebilen değerleri vardır ve sabitlerin sabit değerleri vardır - kolay, değil mi?

 Bu seçeneklerin her ikisine de sahip olmak anlamsız görünebilir, sonuçta sadece bir değişken oluşturup onu asla değiştirmeyebilirsiniz - neden sabit yapılması gerekiyor? Pek çok programcının şok olduğu ortaya çıktı! – programlamada mükemmelden daha az ve hatalar yapıyoruz.

 Sabitleri ve değişkenleri ayırmanın avantajlarından biri, Xcode'un bir hata yapıp yapmadığımızı bize söylemesidir. "Bu tarihi sabit yap, çünkü asla değişmeyeceğini biliyorum" dersek 10 satır sonra değiştirmeyi denersek, Xcode uygulamamızı oluşturmayı reddedecektir.

 Sabitler de önemlidir, çünkü Xcode'un uygulamanızı oluşturma şekli hakkında kararlar almasına izin verirler. Bir değerin asla değişmeyeceğini biliyorsa, kodunuzun daha hızlı çalışmasını sağlamak için optimizasyonlar uygulayabilir.

 Swift'de anahtar kelimeyi kullanarak şöyle bir değişken oluşturursunuz var:

 var name = "Tim McGraw"
 Bunu bir oyun alanına koyalım, böylece geri bildirim almaya başlayabilirsiniz. Satır dışında oradaki her şeyi silin import UIKit(Apple'ın temel iOS çerçevesini çeken ve daha sonra gerekli olan kısım budur) ve bu değişkeni ekleyin.

 Bu bir değişken olduğundan, istediğiniz zaman değiştirebilirsiniz, ancak varanahtar kelimeyi her seferinde kullanmamalısınız – bu yalnızca yeni değişkenler bildirirken kullanılır. Bunu yazmayı deneyin:

 var name = "Tim McGraw"
 name = "Romeo"
 Böylece, ilk satır namedeğişkeni oluşturur ve ona bir başlangıç ​​değeri verir, ardından ikinci satır namedeğişkeni güncelleyerek değeri artık "Romeo" olur. Oyun alanının sonuç alanında her iki değerin de yazdırıldığını göreceksiniz.

 “Tim McGraw” ve “Romeo” yazılı olarak gösterilen oyun alanı.

 Şimdi, bunu bir değişken yerine sabit yapsaydık ne olurdu? Pekala, sabitler letyerine anahtar kelimeyi kullanırlar, böylece ilk kod satırınızı şunun yerine varşunu söylemek için değiştirebilirsiniz :let namevar name

 import UIKit
 let name = "Tim McGraw"
 name = "Romeo"
 Ama şimdi bir sorun var: Xcode, üçüncü satırın yanında kırmızı bir uyarı gösterecek ve kodunuzun altına kırmızı bir alt çizgi çizmiş olması gerekir. Xcode'un mesajı “Değere atanamıyor: 'name' bir 'let' sabitidir”, bu Xcode-speak için "bir sabiti değiştirmeye çalışıyorsunuz ve bunu yapamazsınız".

 3. satırda hata gösteren oyun alanı.

 Dolayısıyla sabitler, Swift'e ve kendinize bir değerin değişmeyeceğine dair söz vermenin harika bir yoludur, çünkü onu değiştirmeye çalışırsanız Xcode çalışmayı reddedecektir. Swift geliştiricileri, kodunuzun anlaşılmasını kolaylaştırdığı için, mümkün olan her yerde sabitleri kullanmak konusunda güçlü bir tercihe sahiptir. Aslında, Xcode size bir şeyi değişken yaptığınızda asla değiştirmeyeceğinizi söyleyecektir!

 Önemli not: Değişken ve sabit adları kodunuzda benzersiz olmalıdır. Aynı değişken adını iki kez kullanmaya çalışırsanız aşağıdaki gibi bir hata alırsınız:

 var name = "Tim McGraw"
 var name = "Romeo"
 Oyun alanı kodunuzda bir hata bulursa, ya kırmızı bir kutuda bir uyarı işaretler ya da çalıştırmayı reddeder. Sonuç bölmesindeki metin normal siyah yerine griye gittiği için ikincisinin olup olmadığını anlarsınız.

 Oyun alanı, geçersiz bir "ad" beyanı nedeniyle 3. satırda hata gösteriyor.


 */

var songs = ["Ah" , "Neden" , "Belki"]
type(of: songs)
songs[1]

//var person = ["first": "Zeki", "middle": "Gokler", "mount": "December"]
//person["Zeki"]


//var action: String
//var person = "hater"

//if person == "hater" {
 //   action = "hate"
//}
var action: String
var stayOutTooLate = true
var nothingInBrain = true

if stayOutTooLate && nothingInBrain {
    action = "cruise"
}else {
    action = "EMPTY"
}

for i in 1...10 {
    print("\(i) * 10 is \(i*10)")
}
var people = ["Players", "Haters", "Heart-Breakers", "Fakers"]
var actions = ["play", "hate", "break", "fake"]
for i in 0..<people.count {
    print("\(people[i]) gonna \(actions[i])")
}

var counter = 0

while true {
    print("Counter is now \(counter)")
    counter += 1
    if counter == 556 {
        break
    }
}

let decision = 3

switch decision {
case 0:
    print("Savaşmamayı seçenler daima kaybeder.Tarih tekerrürden ibarettir.")
case 1:
    print("Çok çalışıyorum demeyle çalışmış olmazsın. Çok çalıştığında zaten er geç karşılığını alırsın.")
case 2:
    print("Küçük adımlar ile alışıp iyi alışkanlıklar kazanmak başarının en kolay yoludur.")
default:
    print("Kim olduğunu öğrenip ona göre çalışmak gerekli.")
}
