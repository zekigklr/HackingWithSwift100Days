import UIKit

//
//

// Başlatıcılar
/**


 Başlatıcılar, yapınızı oluşturmak için farklı yollar sağlayan özel yöntemlerdir. Tüm yapılar, varsayılan olarak bir tane ile gelir, bunlara üye başlatıcı adı verilir - bu, yapıyı oluşturduğunuzda her özellik için bir değer sağlamanızı ister.

 UserBir özelliği olan bir yapı oluşturursak bunu görebilirsiniz :

 struct User {
     var username: String
 }
 Bu yapılardan birini oluşturduğumuzda, bir kullanıcı adı sağlamalıyız:

 var user = User(username: "twostraws")
 Varsayılanı değiştirmek için kendi başlatıcımızı sağlayabiliriz. Örneğin, tüm yeni kullanıcıları "Anonim" olarak oluşturmak ve aşağıdaki gibi bir mesaj yazdırmak isteyebiliriz:

 struct User {
     var username: String

     init() {
         username = "Anonymous"
         print("Creating a new user!")
     }
 }
 Başlatıcılardan önce yazmazsınızfunc , ancak başlatıcı sona ermeden önce tüm özelliklerin bir değeri olduğundan emin olmanız gerekir .

 Şimdi başlatıcımız hiçbir parametre kabul etmiyor, şu şekilde yapıyı oluşturmamız gerekiyor:

 var user = User()
 user.username = "twostraws"
 */

// Mevcut örneğe atıfta bulunarak

/**

 selfYöntemlerin içinde, yapının şu anda kullanılmakta olan örneğini gösteren, adında özel bir sabit elde edersiniz . Bu selfdeğer, özellikle mülkünüzle aynı parametre adlarına sahip başlatıcılar oluşturduğunuzda kullanışlıdır.

 Örneğin, bir özelliğe Personsahip bir yapı oluşturursanız, bir parametreyi namekabul eden bir başlatıcı yazmaya çalışırsanız, özellik ile parametre arasında ayrım yapmanıza yardımcı olur –  özelliği ifade ederken, parametreyi ifade eder.nameselfself.namename

 İşte kodda:

 struct Person {
     var name: String

     init(name: String) {
         print("\(name) was born!")
         self.name = name
     }
 }
 */

// tembel özellikler
/**


 Bir performans optimizasyonu olarak Swift, bazı özellikleri yalnızca gerektiğinde oluşturmanıza izin verir. Örnek olarak, bu FamilyTreeyapıyı düşünün – pek bir işe yaramaz, ancak teoride birisi için bir soy ağacı oluşturmak uzun zaman alır:

 struct FamilyTree {
     init() {
         print("Creating family tree!")
     }
 }
 FamilyTreeBu yapıyı bir yapı içinde bir özellik olarak kullanabiliriz, şöyle Person:

 struct Person {
     var name: String
     var familyTree = FamilyTree()

     init(name: String) {
         self.name = name
     }
 }

 var ed = Person(name: "Ed")
 Ama ya belirli bir kişi için her zaman aile ağacına ihtiyacımız olmasaydı? lazyAnahtar kelimeyi özelliğe eklersek, familyTreeSwift yapıyı yalnızca FamilyTreeilk erişildiğinde oluşturacaktır:

 lazy var familyTree = FamilyTree()
 Öyleyse, "Aile ağacı oluşturuluyor!" mesajı, mülke en az bir kez erişmeniz gerekir:

 ed.familyTree
 */

// Statik özellikler ve yöntemler
/**


 Şimdiye kadar yarattığımız tüm özellikler ve yöntemler, yapıların bireysel örneklerine aitti, bu, bir Studentyapımız olsaydı, her biri kendi özellikleri ve yöntemleri olan birkaç öğrenci örneği oluşturabileceğimiz anlamına gelir:

 struct Student {
     var name: String

     init(name: String) {
         self.name = name
     }
 }

 let ed = Student(name: "Ed")
 let taylor = Student(name: "Taylor")
 Ayrıca Swift'den, static olarak bildirerek yapının tüm örneklerinde belirli özellikleri ve yöntemleri paylaşmasını isteyebilirsiniz .

 Bunu denemek için Student, sınıfta kaç öğrencinin olduğunu saklamak için yapıya statik bir özellik ekleyeceğiz. Her yeni öğrenci oluşturduğumuzda, ona bir tane ekleyeceğiz:

 struct Student {
     static var classSize = 0
     var name: String

     init(name: String) {
         self.name = name
         Student.classSize += 1
     }
 }
 Özellik, yapının örneklerinden ziyade yapının kendisine ait olduğundan classSize, şunu kullanarak okumamız gerekir Student.classSize:

 print(Student.classSize)

 */

// Giriş kontrolu
/**


 Erişim denetimi, hangi kodun özellikleri ve yöntemleri kullanabileceğini kısıtlamanıza olanak tanır. Bu önemlidir, çünkü örneğin, insanların bir mülkü doğrudan okumasını durdurmak isteyebilirsiniz.

 Sosyal güvenlik numaralarını saklama özelliğine Personsahip bir yapı oluşturabiliriz :id

 struct Person {
     var id: String

     init(id: String) {
         self.id = id
     }
 }

 let ed = Person(id: "12345")
 Bu kişi oluşturulduktan sonra, idonun özel olmasını sağlayabiliriz, böylece onu yapının dışından okuyamazsınız - yazmaya ed.idçalışmak işe yaramaz.

 Anahtar kelimeyi şu şekilde kullanın private:

 struct Person {
     private var id: String

     init(id: String) {
         self.id = id
     }
 }
 Artık yalnızca içindeki yöntemler özelliği Personokuyabilir id. Örneğin:

 struct Person {
     private var id: String

     init(id: String) {
         self.id = id
     }

     func identify() -> String {
         return "My social security number is \(id)"
     }
 }
 Diğer bir yaygın seçenek, publicdiğer tüm kodların özelliği veya yöntemi kullanmasına izin veren seçeneğidir.


 */

// Yapılar özeti
/**


 Bu serinin yedinci bölümünün sonuna geldiniz, o yüzden özetleyelim:

 Kendi özelliklerine ve yöntemlerine sahip olabilen yapıları kullanarak kendi türlerinizi oluşturabilirsiniz.
 Değerleri anında hesaplamak için saklanan özellikleri veya hesaplanan özellikleri kullanabilirsiniz.
 Bir yöntemin içindeki bir özelliği değiştirmek istiyorsanız, onu olarak işaretlemeniz gerekir mutating.
 Başlatıcılar, yapılar oluşturan özel yöntemlerdir. Varsayılan olarak bir üye başlatıcı alırsınız, ancak kendinizinkini oluşturursanız tüm özelliklere bir değer vermelisiniz.
 selfBir yöntem içindeki bir yapının geçerli örneğine başvurmak için sabiti kullanın .
 Anahtar lazysözcük, Swift'e yalnızca ilk kullanıldıklarında özellikler oluşturmasını söyler.
 staticAnahtar sözcüğü kullanarak bir yapının tüm örneklerinde özellikleri ve yöntemleri paylaşabilirsiniz .
 Erişim denetimi, hangi kodun özellikleri ve yöntemleri kullanabileceğini kısıtlamanıza olanak tanır.

 */

