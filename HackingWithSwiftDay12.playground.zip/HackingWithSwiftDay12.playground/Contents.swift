import UIKit

//Hacking With Swift Day 12
//Day 12 – optionals, unwrapping, and typecasting

// Eksik verileri işleme
/**


 Int5 gibi değerleri tutacak türler kullandık . Ancak age, kullanıcılar için bir mülk depolamak isteseydiniz, birinin yaşını bilmiyorsanız ne yapardınız?

 “Peki, 0 saklayacağım” diyebilirsiniz, ancak o zaman yeni doğan bebekler ve yaşını bilmediğiniz insanlar arasında kafanız karışır. Her ikisi de imkansız yaşlar olan “bilinmeyen”i temsil etmek için 1000 veya -1 gibi özel bir sayı kullanabilirsiniz, ancak o zaman kullanıldığı tüm yerlerde bu sayıyı gerçekten hatırlar mıydınız?

 Swift'in çözümüne isteğe bağlı denir ve her türden isteğe bağlı seçenek oluşturabilirsiniz. İsteğe bağlı bir tamsayı 0 veya 40 gibi bir sayıya sahip olabilir, ancak hiç değeri olmayabilir - Swift'de tam anlamıyla eksik olabilir nil.

 Bir türü isteğe bağlı yapmak için, ondan sonra bir soru işareti ekleyin. Örneğin, aşağıdaki gibi isteğe bağlı bir tamsayı yapabiliriz:

 var age: Int? = nil
 Bu herhangi bir sayı tutmaz - hiçbir şey tutmaz. Ama daha sonra o yaşı öğrenirsek kullanabiliriz:

 age = 38 */

// Paketi açma isteğe bağlı
/**

 İsteğe bağlı dizeler "Merhaba" gibi bir dize içerebilir veya sıfır olabilir - hiçbir şey olmayabilir.

 Bu isteğe bağlı dizeyi düşünün:

 var name: String? = nil
 Kullanırsak ne olur name.count? Gerçek bir dize, countkaç harfe sahip olduğunu saklayan bir özelliğe sahiptir, ancak bu nil– boş bellektir, bir dize değil, bu nedenle count.

 Bu nedenle, okumaya çalışmak name.countgüvenli değildir ve Swift buna izin vermez. Bunun yerine, isteğe bağlı olanın içine bakmalı ve orada ne olduğunu görmeliyiz - unwrapping olarak bilinen bir süreç .

 Seçenekleri açmanın yaygın bir yolu, if letbir koşulla açılan sözdizimidir. İsteğe bağlı içinde bir değer varsa, onu kullanabilirsiniz, ancak yoksa koşul başarısız olur.

 Örneğin:

 if let unwrapped = name {
     print("\(unwrapped.count) letters")
 } else {
     print("Missing name.")
 }
 Eğer bir dizge tutarsa, düzenli olarak nameiçine konur ve onun özelliğini koşul içinde okuyabiliriz. Alternatif olarak, boşsa kod çalıştırılacaktır.unwrappedStringcountnameelse


 */

// Koruma ile açma
/**
 
 Opsiyonelleri de açan if letis öğesine bir alternatif . sizin için isteğe bağlı bir paketi açar, ancak içinde bulursa , kullandığınız işlevden, döngüden veya koşuldan çıkmanızı bekler.guard letguard letnil

 if letBununla birlikte, ve arasındaki en büyük fark guard let, paketlenmemiş isteğe bağlı öğenizin guardkoddan sonra kullanılabilir durumda kalmasıdır.

 greet()Bir fonksiyonla deneyelim . Bu, isteğe bağlı bir dizeyi tek parametresi olarak kabul eder ve paketini açmaya çalışır, ancak içinde hiçbir şey yoksa bir mesaj yazdırır ve çıkar. İsteğe bağlı seçenekler , sona guard leterdikten sonra kal ile guardkapatıldığından, sarmalanmamış dizeyi işlevin sonunda yazdırabiliriz:

 func greet(_ name: String?) {
     guard let unwrapped = name else {
         print("You didn't provide a name!")
         return
     }

     print("Hello, \(unwrapped)!")
 }
 Kullanmak guard let, işlevlerinizin başlangıcında sorunlarla başa çıkmanıza ve ardından hemen çıkmanıza olanak tanır. Bu, işlevinizin geri kalanının mutlu yol olduğu anlamına gelir - her şey doğruysa kodunuzun izlediği yol.


 */

// Paketi açmaya zorla
/**


 Seçenekler, orada olabilecek veya olmayabilecek verileri temsil eder, ancak bazen bir değerin sıfır olmadığından emin olursunuz. Bu durumlarda Swift, isteğe bağlı olanı açmaya zorlamanıza izin verir: onu isteğe bağlı bir türden isteğe bağlı olmayan bir türe dönüştürün.

 Örneğin, bir sayı içeren bir dizginiz varsa, onu şuna dönüştürebilirsiniz Int:

 let str = "5"
 let num = Int(str)
 Bu, isteğe bağlınum hale getirir , çünkü "5" yerine "Balık" gibi bir dize dönüştürmeyi denemiş olabilirsiniz. Int

 Swift, dönüştürmenin işe yarayacağından emin olmasa da, kodun güvenli olduğunu görebilir, böylece aşağıdaki gibi yazarak sonucu açmaya !zorlayabilirsiniz Int(str):

 let num = Int(str)!
 Swift, isteğe bağlı paketi hemen açacak ve numbir . Ancak yanılıyorsanız – tamsayıya dönüştürülemeyen bir şeyse – kodunuz çökecektir.IntInt?str

 Sonuç olarak, yalnızca güvenli olduğundan emin olduğunuzda paketi açmaya zorlamalısınız - buna genellikle çarpışma operatörü denmesinin bir nedeni vardır.


 */

// Dolaylı olarak açılmamış isteğe bağlı seçenekler
/**

 Normal opsiyonlar gibi, örtük olarak açılmamış opsiyonlar bir değer içerebilir veya nil. Ancak, normal seçeneklerden farklı olarak, bunları kullanmak için paketini açmanıza gerek yoktur: sanki hiç isteğe bağlı değillermiş gibi kullanabilirsiniz.

 Örtülü olarak açılmamış isteğe bağlı seçenekler, tür adınızdan sonra bir ünlem işareti eklenerek oluşturulur, şöyle:

 let age: Int! = nil
 Zaten açılmamış gibi davrandıkları için, örtülü olarak açılmamış isteğe bağlı seçenekleri kullanmanıza if letveya kullanmanıza gerek yoktur. guard letAncak, bunları kullanmaya çalışırsanız ve hiçbir değeri yoksa – eğer öyleyse nil– kodunuz çöker.

 Örtülü olarak açılmamış seçenekler vardır, çünkü bazen bir değişken hayata sıfır olarak başlar, ancak onu kullanmanız gerekmeden önce her zaman bir değere sahip olur. İhtiyaç duyduğunuzda bir değeri olacağını bildiğiniz için, sürekli yazmak zorunda kalmamanızda fayda var if let.

 Olduğu söyleniyor, bunun yerine normal opsiyonları kullanabiliyorsanız, bu genellikle iyi bir fikirdir.
 */

// sıfır birleştirme
/**


 Sıfır birleştirme operatörü, isteğe bağlı bir paketi açar ve varsa içindeki değeri döndürür. Bir değer yoksa - isteğe bağlıysa nil- bunun yerine varsayılan bir değer kullanılır. Her iki durumda da sonuç isteğe bağlı olmayacaktır: ya isteğe bağlı içinden gelen değer ya da yedek olarak kullanılan varsayılan değer olacaktır.

 İşte tek parametresi olarak bir tamsayı kabul eden ve isteğe bağlı bir dize döndüren bir işlev:

 func username(for id: Int) -> String? {
     if id == 1 {
         return "Taylor Swift"
     } else {
         return nil
     }
 }
 nilBunu ID 15 ile çağırırsak , kullanıcı tanınmadığı için geri döneriz , ancak sıfır birleştirme ile aşağıdaki gibi varsayılan bir “Anonim” değeri sağlayabiliriz:

 let user = username(for: 15) ?? "Anonymous"
 Bu, fonksiyondan gelen sonucu kontrol edecektir username(): eğer bir dizge ise, o zaman çözülecek ve içine yerleştirilecektir user, ancak eğer niliçinde ise, bunun yerine “Anonim” kullanılacaktır.


 */

// Opsiyonel zincirleme
/**


 Swift, seçenekleri kullanırken bize bir kısayol sağlar: gibi bir şeye erişmek istiyorsanız ve isteğe bağlıysa a.b.c, isteğe bağlı zincirlemeyib etkinleştirmek için ondan sonra bir soru işareti yazabilirsiniz : .a.b?.c

 Bu kod çalıştırıldığında, Swift bbir değerin olup olmadığını kontrol edecek ve eğer öyleyse nilsatırın geri kalanı yok sayılacak – Swift nilhemen dönecektir. Ancak bir değeri varsa , paketi açılır ve yürütme devam eder.

 Bunu denemek için, işte bir dizi isim:

 let names = ["John", "Paul", "George", "Ringo"]
 Bu dizinin, varsa veya dizi boşsa firstilk adı döndürecek olan özelliğini kullanacağız . nilDaha sonra uppercased()sonucu büyük harfli bir dize yapmak için çağırabiliriz:

 let beatle = names.first?.uppercased()
 Bu soru işareti isteğe bağlı zincirlemedir - eğer firstdönerse nilSwift onu büyük harfe çevirmeye çalışmaz ve beatlehemen olarak nilayarlanır.


 */

//İsteğe bağlı deneme
/**
 

 Fırlatma fonksiyonlarından bahsederken şu koda baktık:

 enum PasswordError: Error {
     case obvious
 }

 func checkPassword(_ password: String) throws -> Bool {
     if password == "password" {
         throw PasswordError.obvious
     }

     return true
 }

 do {
     try checkPassword("password")
     print("That password is good!")
 } catch {
     print("You can't use that password.")
 }
 Bu, hataları incelikle işlemek için do, try, ve kullanarak bir fırlatma işlevi çalıştırır .catch

 için iki alternatif vardır try, her ikisi de artık seçenekleri anladığınız ve paketi açmaya zorladığınız için daha anlamlı olacaktır.

 Birincisi try?, ve fırlatma işlevlerini isteğe bağlı döndüren işlevlere dönüştürür. İşlev bir hata verirse nil, sonuç olarak gönderilirsiniz, aksi takdirde isteğe bağlı olarak sarılmış dönüş değeri alırsınız.

 Kullanarak try?şöyle koşabiliriz checkPassword():

 if let result = try? checkPassword("password") {
     print("Result was \(result)")
 } else {
     print("D'oh.")
 }
 Diğer alternatif ise try!, işlevin başarısız olmayacağından emin olduğunuzda kullanabileceğiniz . İşlev bir hata verirse kodunuz çökecektir.

 Bunu kullanarak try!kodu yeniden yazabiliriz:

 try! checkPassword("sekrit")
 print("OK!")

 */

// Başarısız başlatıcılar
/**

 Zorla açma hakkında konuşurken bu kodu kullandım:

 let str = "5"
 let num = Int(str)
 Bu, bir dizeyi bir tamsayıya dönüştürür, ancak orada herhangi bir dize geçirmeyi deneyebileceğiniz için gerçekte geri aldığınız şey isteğe bağlı bir tamsayıdır.

 Bu, başarısız bir başlatıcıdır : çalışabilecek veya çalışmayabilecek bir başlatıcı. Bunları kendi yapılarınızda ve sınıflarınızda init?()yerine yerine kullanarak yazabilir ve bir şeyler ters giderse init()geri dönebilirsiniz . nilDönüş değeri, istediğiniz şekilde açmanız için türünüzün isteğe bağlı bir değeri olacaktır.

 Örnek olarak, Persondokuz harfli bir kimlik dizesi kullanılarak oluşturulması gereken bir yapıyı kodlayabiliriz. Dokuz harfli bir dizeden başka bir şey kullanılırsa geri döneriz nil, aksi takdirde normal şekilde devam ederiz.

 İşte Swift'de bu:

 struct Person {
     var id: String

     init?(id: String) {
         if id.count == 9 {
             self.id = id
         } else {
             return nil
         }
     }
 }

 */

// tipleme
/**


 Swift, her bir değişkeninizin türünü her zaman bilmelidir, ancak bazen siz Swift'den daha fazla bilgi bilirsiniz. Örneğin, burada üç sınıf vardır:

 class Animal { }
 class Fish: Animal { }

 class Dog: Animal {
     func makeNoise() {
         print("Woof!")
     }
 }
 Birkaç balık ve birkaç köpek oluşturabilir ve bunları aşağıdaki gibi bir diziye koyabiliriz:

 let pets = [Fish(), Dog(), Fish(), Dog()]
 Swift her ikisini de görebilir Fishve sınıftan Dogmiras alabilir, bu nedenle bir dizi Animalyapmak için tür çıkarımını kullanır .petsAnimal

 petsDizi üzerinde döngü yapmak ve tüm köpeklerden havlamasını istiyorsak, bir typecast yapmamız gerekir: Swift, her bir evcil hayvanın bir Dognesne olup olmadığını kontrol edecek ve eğer öyleyse, çağırabiliriz makeNoise().

 as?Bu , isteğe bağlı bir döndüren adlı yeni bir anahtar kelime kullanır : bu nil, typecast başarısız olursa, aksi takdirde dönüştürülmüş bir tür olacaktır.

 Döngüyü Swift'de şu şekilde yazıyoruz:

 for pet in pets {
     if let dog = pet as? Dog {
         dog.makeNoise()
     }
 }

 */

// Opsiyonel özet
/**


 Bu serinin onuncu bölümünün sonuna geldiniz, o halde özetleyelim:

 Seçenekler, bir değerin yokluğunu açık ve net bir şekilde göstermemize izin verir.
 Swift, seçenekleri açmadan kullanmamıza if letveya kullanmamıza izin vermiyor guard let.
 Paketi açma seçeneklerini bir ünlem işaretiyle zorlayabilirsiniz, ancak paketi açmaya zorlamaya çalışırsanız nilkodunuz çökecektir.
 Dolaylı olarak açılmamış opsiyonlar, normal opsiyonların güvenlik kontrollerine sahip değildir.
 İsteğe bağlı bir paketi açmak için sıfır birleştirmeyi kullanabilir ve içinde hiçbir şey yoksa varsayılan bir değer sağlayabilirsiniz.
 İsteğe bağlı zincirleme, isteğe bağlı olanı işlemek için kod yazmamıza izin verir, ancak isteğe bağlı boş çıkarsa kod yok sayılır.
 try?Bir fırlatma işlevini isteğe bağlı bir dönüş değerine dönüştürmek veya try!bir hata oluştuğunda çökmek için kullanabilirsiniz .
 Başlatıcınızın hatalı girdi verildiğinde başarısız olmasına ihtiyacınız varsa, başarısız init?()bir başlatıcı yapmak için kullanın.
 Bir tür nesneyi diğerine dönüştürmek için typecasting'i kullanabilirsiniz.

 */

