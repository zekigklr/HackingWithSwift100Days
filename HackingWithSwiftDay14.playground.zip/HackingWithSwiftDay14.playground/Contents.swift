import UIKit

//Hacking With Swift Day 14
//Day 14 – Swift review, day two
//Burada sadece bir kac deneme yaptım tum halini word belgesinde tutuyorum.

func myFavoriteAlbum(name: String){
    print("My favorite album is \(name)")
}

myFavoriteAlbum(name: "fearless")

func countLetterInString(in string: String){
    print("The string \(string) has \(string.count) letters.")
}
countLetterInString(in: "hello")

func getHaterStatus(weather: String) -> String?{
    if weather == "sunny" {
        return nil
    }else {
        return "Hate"
    }
}
getHaterStatus(weather: "sunny")

func albumReleased(year: Int) -> String? {
    switch year {
    case 2006: return "Taylor Swift"
    case 2008: return "Fearless"
    case 2010: return "Speak Now"
    case 2012: return "Red"
    case 2014: return "1989"
    default: return nil
    }
}

let album = albumReleased(year: 2006) ?? "unknown"
print("The album is \(String(describing: album))")


class Singer {
    var name: String
    var age: Int
    
    init(name: String, age: Int){
        self.name = name
        self.age = age
    }
    func sing(){
        print("La la la la")
    }
}
var taylor = Singer(name: "Taylor", age: 25)
taylor.name
taylor.age
taylor.sing()

