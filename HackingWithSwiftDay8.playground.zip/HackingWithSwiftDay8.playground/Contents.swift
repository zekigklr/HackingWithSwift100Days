import UIKit

//Hacking With Swift Day 8
//Day 8 – structs, properties, and methods

struct Sport {
    var name: String
}

var tennis = Sport(name: "Tennis")
print(tennis.name)
//
/*
 Kendi yapılarınızı oluşturma

 Swift, kendi türlerinizi iki şekilde tasarlamanıza izin verir; bunlardan en yaygın olanı yapılar veya sadece yapılar olarak adlandırılır . Yapılara kendi değişkenleri ve sabitleri ve kendi işlevleri verilebilir, daha sonra istediğiniz şekilde oluşturulabilir ve kullanılabilir.

 Basit bir örnekle başlayalım: SportAdını bir dizge olarak saklayan bir yapı oluşturacağız. Yapıların içindeki değişkenlere özellikler denir , bu nedenle bu, tek özelliği olan bir yapıdır:

 struct Sport {
     var name: String
 }
 Bu, türü tanımlar, böylece şimdi bir örneğini oluşturabilir ve kullanabiliriz:

 var tennis = Sport(name: "Tennis")
 print(tennis.name)
 Hem ve hem de değişken yaptık name, tennisböylece onları normal değişkenler gibi değiştirebiliriz:

 tennis.name = "Lawn tennis"
 Özellikler, normal değişkenler gibi varsayılan değerlere sahip olabilir ve genellikle Swift'in tür çıkarımına güvenebilirsiniz.


 */

//
/*
 Hesaplanan özellikler

 Az önce şöyle bir Sportyapı oluşturduk:

 struct Sport {
     var name: String
 }
 Bu, depolayan bir nameString özelliğine sahiptir . Bunlara saklı özellikler denir , çünkü Swift'in hesaplanmış özellik adı verilen farklı bir özelliği vardır - değerini bulmak için kod çalıştıran bir özellik.

 Yapıya başka bir depolanmış özellik ekleyeceğiz Sport, ardından hesaplanmış bir özellik. İşte nasıl göründüğü:

 struct Sport {
     var name: String
     var isOlympicSport: Bool

     var olympicStatus: String {
         if isOlympicSport {
             return "\(name) is an Olympic sport"
         } else {
             return "\(name) is not an Olympic sport"
         }
     }
 }
 Gördüğünüz olympicStatusgibi normal gibi görünüyor String, ancak diğer özelliklere bağlı olarak farklı değerler döndürüyor.

 Yeni bir örnek oluşturarak deneyebiliriz Sport:

 let chessBoxing = Sport(name: "Chessboxing", isOlympicSport: false)
 print(chessBoxing.olympicStatus)
 */

//Mülkiyet gözlemcileri
/*
 

 Özellik gözlemciler, herhangi bir özellik değişikliğinden önce veya sonra kod çalıştırmanıza izin verir. ProgressBunu göstermek için, bir görevi ve tamamlanma yüzdesini izleyen bir yapı yazacağız :

 struct Progress {
     var task: String
     var amount: Int
 }
 Artık bu yapının bir örneğini oluşturabilir ve zaman içindeki ilerlemesini ayarlayabiliriz:

 var progress = Progress(task: "Loading data", amount: 0)
 progress.amount = 30
 progress.amount = 80
 progress.amount = 100
 Olmasını istediğimiz şey, Swift'in her amountdeğişiklikte bir mesaj yazdırmasıdır ve bunun için bir didSetözellik gözlemcisi kullanabiliriz. Bu, her amountdeğişiklikte bazı kodlar çalıştırır:

 struct Progress {
     var task: String
     var amount: Int {
         didSet {
             print("\(task) is now \(amount)% complete")
         }
     }
 }
 Bir özellik değişmeden öncewillSet harekete geçmek için de kullanabilirsiniz , ancak bu nadiren kullanılır.
 */

//
/*
 yöntemler

 Yapıların içinde işlevler olabilir ve bu işlevler yapının özelliklerini gerektiği gibi kullanabilir. Yapıların içindeki işlevlere yöntemler denir , ancak yine de aynı funcanahtar sözcüğü kullanırlar.

 Bunu bir Citystruct ile gösterebiliriz. Bu, populationşehirde kaç kişinin olduğunu saklayan bir özelliğe ve ayrıca collectTaxes()nüfus sayısını 1000 ile çarparak döndüren bir yönteme sahip olacak. Yöntem ona ait olduğu için mevcut şehrin mülkünü Cityokuyabilir .population

 İşte kod:

 struct City {
     var population: Int

     func collectTaxes() -> Int {
         return population * 1000
     }
 }
 Bu yöntem yapıya aittir, bu nedenle yapı örneklerinde bunu şöyle çağırırız:

 let london = City(population: 9_000_000)
 london.collectTaxes()

 */

//
/*
 Mutasyon yöntemleri

 Bir yapının değişken bir özelliği varsa ancak yapının örneği bir sabit olarak oluşturulmuşsa, bu özellik değiştirilemez – yapı sabittir, dolayısıyla nasıl oluşturulduklarına bakılmaksızın tüm özellikleri de sabittir.

 Sorun şu ki, yapıyı oluşturduğunuzda Swift'in onu sabitlerle mi yoksa değişkenlerle mi kullanacağınız konusunda hiçbir fikri yoktur, bu nedenle varsayılan olarak güvenli yaklaşımı benimser: Swift, özellikle talep etmedikçe özellikleri değiştiren yöntemler yazmanıza izin vermez.

 Bir yöntemin içindeki bir özelliği değiştirmek istediğinizde , bunu aşağıdaki gibi anahtar kelimeyi kullanarak işaretlemeniz gerekir mutating:

 struct Person {
     var name: String

     mutating func makeAnonymous() {
         name = "Anonymous"
     }
 }
 PersonÖzelliği değiştirdiği için Swift, yalnızca değişken olan örneklerde bu yöntemin çağrılmasına izin verir :

 var person = Person(name: "Ed")
 person.makeAnonymous()
 */

//
/*
 Dizelerin özellikleri ve yöntemleri

 Şimdiye kadar pek çok dize kullandık ve bunların yapılar olduğu ortaya çıktı - dizeyi sorgulamak ve işlemek için kullanabileceğimiz kendi yöntemleri ve özellikleri var.

 İlk önce bir test dizisi oluşturalım:

 let string = "Do or do not, there is no try."
 countÖzelliğini kullanarak bir dizedeki karakter sayısını okuyabilirsiniz :

 print(string.count)
 hasPrefix()Dize belirli harflerle başlıyorsa true döndüren bir yöntemleri vardır:

 print(string.hasPrefix("Do"))
 Metodunu çağırarak bir dizgiyi büyük harf yapabilirsiniz uppercased():

 print(string.uppercased())
 Hatta Swift'in dizenin harflerini bir diziye ayırmasını bile sağlayabilirsiniz:

 print(string.sorted())
 Dizelerin çok daha fazla özelliği ve yöntemi vardır – string.Xcode'un kod tamamlama seçeneklerini getirmek için yazmayı deneyin.


 */

//
/*
 Dizilerin özellikleri ve yöntemleri

 Diziler aynı zamanda yapılardır, bu onların da diziyi sorgulamak ve işlemek için kullanabileceğimiz kendi yöntemlerine ve özelliklerine sahip oldukları anlamına gelir.

 İşte başlamamız için basit bir dizi:

 var toys = ["Woody"]
 countÖzelliğini kullanarak bir dizideki öğelerin sayısını okuyabilirsiniz :

 print(toys.count)
 Yeni bir öğe eklemek istiyorsanız, aşağıdaki append()gibi yöntemi kullanın:

 toys.append("Buzz")
 Bir dizinin içindeki herhangi bir öğeyi, firstIndex()yöntemini kullanarak aşağıdaki gibi bulabilirsiniz:

 toys.firstIndex(of: "Buzz")
 Diziler 0'dan sayıldığından bu 1 döndürür.

 Dizelerde olduğu gibi, Swift'in dizinin öğelerini alfabetik olarak sıralamasını sağlayabilirsiniz:

 print(toys.sorted())
 Son olarak, bir öğeyi kaldırmak istiyorsanız, aşağıdaki remove()gibi yöntemi kullanın:

 toys.remove(at: 0)
 Dizilerin çok daha fazla özelliği ve yöntemi vardır – toys.Xcode'un kod tamamlama seçeneklerini getirmek için yazmayı deneyin.
 */


